/* Raw JS */
$(document).ready(function() {
    $('a.dropdown-item.fs08').each(function() {
        if ($(this).html() == '繁體中文') {
            $(this).html('简体中文');
        }
    });
});
/* End Raw JS */
